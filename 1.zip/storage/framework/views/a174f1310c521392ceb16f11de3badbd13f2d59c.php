<div class="w-full block mt-8 ">
    <div class="d-flex flex-column sm:flex-no-wrap justify-between">
        <div class="w-full bg-gray-200 text-center border border-gray-300 px-8 py-6 pz-4 rounded">
            <h3 class="text-black uppercase font-bold">
                <span class="text-4xl"><?php echo e(sprintf("%02d", count($parents))); ?></span>
                <span class="leading-tight">Parents</span>
            </h3>
        </div>
        <div class="w-full bg-gray-200 text-center border border-gray-300 px-8 py-6 pz-4 rounded">
            <h3 class="text-black uppercase font-bold">
                <span class="text-4xl"><?php echo e(sprintf("%02d", count($teachers))); ?></span>
                <span class="leading-tight">Teachers</span>
            </h3>
        </div>
        <div class="w-full bg-gray-200 text-center border border-gray-300 px-8 py-6 pz-4 rounded">
            <h3 class="text-black uppercase font-bold">
                <span class="text-4xl"><?php echo e(sprintf("%02d", count($students))); ?></span>
                <span class="leading-tight">Students</span>
            </h3>
        </div>
    </div>
</div>
<?php /**PATH D:\INT221\laravel\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>