<div class="sidebar hidden sm:block w-0 sm:w-1/6 bg-gray-200 h-screen shadow fixed top-0 left-0 bottom-0 z-40 overflow-y-auto">
    <div class="mb-6 mt-20 px-6">
        <a href="{{ route('home') }}" class="flex items-center text-black py-2 hover:text-blue-700">
            <span class="ml-2 text-sm font-semibold">Home</span>
        </a>
        @role('Admin')
        <a href="{{ route('classes.index') }}" class="flex items-center text-black py-2 hover:text-blue-700">
            <span class="ml-2 text-sm font-semibold">Classes</span>
        </a>
        <a href="{{ route('subject.index') }}" class="flex items-center text-black py-2 hover:text-blue-700">
            <span class="ml-2 text-sm font-semibold">Subjects</span>
        </a>
        <a href="{{ route('teacher.index') }}" class="flex items-center text-black py-2 hover:text-blue-700">
            <span class="ml-2 text-sm font-semibold">Teachers</span>
        </a>
        <a href="{{ route('parents.index') }}" class="flex items-center text-black py-2 hover:text-blue-700">
            <span class="ml-2 text-sm font-semibold">Parents</span>
        </a>
        <a href="{{ route('student.index') }}" class="flex items-center text-black py-2 hover:text-blue-700">
            <span class="ml-2 text-sm font-semibold">Students</span>
        </a>
        @endrole
    </div>
</div>
