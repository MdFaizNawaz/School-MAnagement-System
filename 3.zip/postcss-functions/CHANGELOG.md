# 3.0.0 - 2017-08-13
* Rewrite in ES6.
* Add Babel.
* Replace Mocha with AVA.
* Update dependencies.
* Add ability to use functions in selectors.

# 2.1.1 - 2016-10-08
* Only apply promises if function is asynchronous. Fixes out-of-memory issues.

# 2.1.0 - 2016-01-28
* Replace undocumented extend method with object-assign
* Replace reduce-function-call with postcss-value-parser
* Add support for promises

# 2.0.0 - 2015-11-09
* Update to PostCSS 5.x

# 1.0.0 - 2015-08-04
* Initial release
